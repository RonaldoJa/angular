
export interface EventoInterface {

    titulo: string;
    descripcion: string;
    participantes: string;
    cupos: number;
    fecha: string;
}