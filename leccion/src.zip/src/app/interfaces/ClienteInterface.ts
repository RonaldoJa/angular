
export interface ClienteInterface {

    cedula: string;
    nombres: string;
    apellidos: string;
    ciudad: string;
}